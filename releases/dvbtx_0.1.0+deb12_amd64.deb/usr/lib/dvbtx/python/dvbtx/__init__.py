"""dvbtx - home DVB transmitter: ingest (ffmpeg) -> multiplex + SI -> modulation -> SDR."""

__version__ = "0.1.0"
